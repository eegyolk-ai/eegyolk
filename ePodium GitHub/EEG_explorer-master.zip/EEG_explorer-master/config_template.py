# config.py template
# Add your respective folder names and save as config.py

ROOT =  "..."
PATH_CODE =  "..."
PATH_DATA =  "..."
PATH_OUTPUT =  "..."