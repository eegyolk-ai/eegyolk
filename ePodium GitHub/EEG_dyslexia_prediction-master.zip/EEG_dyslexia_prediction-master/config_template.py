# config.py template
# Add your respective folder names and save as config.py

ROOT = "..."
PATH_CODE = ROOT + "..."
PATH_DATA = ROOT + "..."
PATH_OUTPUT = PATH_DATA + "..."
PATH_METADATA = PATH_DATA + "..."